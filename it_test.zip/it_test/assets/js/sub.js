(function($) {

	$('.img_tile a.button').hover(
		function () {
			$(this).parents("div.img_tile").toggleClass("img_crean");
			$(this).parents("div.img_tile").toggleClass("image_overlay");
			$(this).parent().prev('h3').hide()
		},
		function () {
			$(this).parents("div.img_tile").toggleClass("image_overlay");
			$(this).parents("div.img_tile").toggleClass("img_crean");
			$(this).parent().prev('h3').show()
		}
		);

})(jQuery);